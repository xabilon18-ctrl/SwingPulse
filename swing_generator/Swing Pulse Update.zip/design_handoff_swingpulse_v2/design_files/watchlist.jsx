// SwingPulse v2 — Watchlist
const WLIcon = window.Icon;
const Watchlist = ({ tweaks }) => {
  const Icon = WLIcon;
  const [filter, setFilter] = React.useState('All');
  const filters = [
    { id: 'All', label: 'All', num: 16 },
    { id: 'Buy', label: 'Buy', num: 4 },
    { id: 'Sell', label: 'Sell', num: 2 },
    { id: 'Signal', label: 'Has Signal', num: 6 },
    { id: 'Up', label: 'Uptrend', num: 8 },
  ];

  return (
    <>
      <div className="wl-summary">
        <div className="wl-stat">
          <div className="lbl">Watchlist Size</div>
          <div className="val">16</div>
          <div className="delta">8 in uptrend</div>
        </div>
        <div className="wl-stat">
          <div className="lbl">Active Signals</div>
          <div className="val" style={{ color: 'var(--accent-2)' }}>6</div>
          <div className="delta" style={{ color: 'var(--fg-2)' }}>3 alerts</div>
        </div>
      </div>

      <div className="filter-pills">
        {filters.map(f => (
          <button key={f.id} className={filter === f.id ? 'active' : ''} onClick={() => setFilter(f.id)}>
            {f.label} <span className="num">{f.num}</span>
          </button>
        ))}
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', margin: '4px 2px 10px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, fontWeight: 600 }}>
          <Icon.Star style={{ width: 14, height: 14, color: 'var(--warn)' }} />
          <span>My Watchlist</span>
        </div>
        <button className="chip" style={{ cursor: 'pointer' }}>Sort: Signal First ▼</button>
      </div>

      <div>
        <WLRow icon="gold" iconLabel="AU" ticker="GOLD" name="Commodity · Commodities" price="4,555.80" pct="-0.8%" trend="bear" tags={[{ label: 'NEUTRAL' }, { label: 'Counter-trend', tone: 'accent' }, { label: '1d ago' }]} alert />
        <WLRow icon="btc" iconLabel="₿" ticker="BTCUSD" name="Crypto · Crypto" price="80,927.05" pct="+6.1%" trend="bull" tags={[{ label: 'NEUTRAL' }, { label: 'Counter-trend', tone: 'accent' }, { label: '1d ago' }]} alert />
        <WLRow icon="eth" iconLabel="Ξ" ticker="ETHUSD" name="Crypto · Crypto" price="2,361.18" pct="+4.7%" trend="bull" tags={[{ label: 'NEUTRAL' }, { label: 'Counter-trend', tone: 'accent' }, { label: '1d ago' }]} alert />
        <WLRow icon="us"  iconLabel="US" ticker="US100" name="US Index · Index" price="28,015.06" pct="+3.6%" trend="bull" tags={[{ label: 'UPTREND', tone: 'bull' }, { label: 'Quad Bull', tone: 'bull' }, { label: '4TF✓', tone: 'bull' }, { label: '1d ago' }]} />
        <WLRow icon="" iconLabel="QC" ticker="QCOM" name="Qualcomm · US100" price="186.55" pct="+24.4%" trend="bull" tags={[{ label: 'UPTREND', tone: 'bull' }, { label: 'Quad Bull', tone: 'bull' }, { label: '4TF✓', tone: 'bull' }, { label: '1d ago' }]} alert />
        <WLRow icon="" iconLabel="DAX" ticker="DAX" name="EU Index · Index" price="24,401.70" pct="+1.3%" trend="bull" tags={[{ label: 'BP3', tone: 'bull' }, { label: 'STANDARD' }, { label: 'Quad Bull', tone: 'bull' }]} alert />
        <WLRow icon="" iconLabel="NF" ticker="NFLX" name="Netflix · US100" price="612.40" pct="-2.8%" trend="bear" tags={[{ label: 'SP1', tone: 'bear' }, { label: 'HIGH', tone: 'accent' }, { label: 'Triple Bear', tone: 'bear' }]} alert />
      </div>
    </>
  );
};

const WLRow = ({ icon, iconLabel, ticker, name, price, pct, trend, tags, alert }) => (
  <div className="wl-row">
    <div className={`wl-icon ${icon}`}>{iconLabel}</div>
    <div className="info">
      <div className="ticker">{ticker} <Icon.Star style={{ width: 11, height: 11, color: 'var(--warn)', marginLeft: 4 }} /></div>
      <div className="name">{name}</div>
      <div className="chips">
        {tags.map((t, i) => {
          let cls = 'chip tiny';
          if (t.tone) cls += ` ${t.tone}`;
          return <span key={i} className={cls}>{t.label}</span>;
        })}
      </div>
    </div>
    <div className="right">
      <div className="price mono">{price}</div>
      <div className={`pct ${trend}`}>{trend === 'bull' ? '▲' : '▼'} {pct}</div>
      {alert && <span className="alert"><Icon.Bolt style={{ width: 9, height: 9 }} /> Alert</span>}
    </div>
  </div>
);

window.Watchlist = Watchlist;
