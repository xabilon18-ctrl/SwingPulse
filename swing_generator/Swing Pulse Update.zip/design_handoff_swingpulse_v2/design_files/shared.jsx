// SwingPulse v2 — shared icons + small primitives
const Icon = {
  Logo: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M3 17 L8 11 L12 14 L16 8 L21 12" />
      <circle cx="16" cy="8" r="1.4" fill="currentColor" stroke="none" />
    </svg>
  ),
  Refresh: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M3 12a9 9 0 0 1 15-6.7L21 8" /><path d="M21 3v5h-5" />
      <path d="M21 12a9 9 0 0 1-15 6.7L3 16" /><path d="M3 21v-5h5" />
    </svg>
  ),
  Search: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" />
    </svg>
  ),
  Bell: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M6 8a6 6 0 1 1 12 0c0 7 3 7 3 9H3c0-2 3-2 3-9Z" /><path d="M10 21a2 2 0 0 0 4 0" />
    </svg>
  ),
  Star: (p) => (
    <svg viewBox="0 0 24 24" fill="currentColor" {...p}>
      <path d="m12 2 2.9 6.5L22 9.6l-5.2 5 1.4 7.4L12 18.6 5.8 22l1.4-7.4-5.2-5 7.1-1.1Z" />
    </svg>
  ),
  StarO: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" {...p}>
      <path d="m12 2 2.9 6.5L22 9.6l-5.2 5 1.4 7.4L12 18.6 5.8 22l1.4-7.4-5.2-5 7.1-1.1Z" />
    </svg>
  ),
  TrendUp: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <polyline points="3 17 9 11 13 15 21 7" /><polyline points="14 7 21 7 21 14" />
    </svg>
  ),
  TrendDown: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <polyline points="3 7 9 13 13 9 21 17" /><polyline points="14 17 21 17 21 10" />
    </svg>
  ),
  Eye: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z" /><circle cx="12" cy="12" r="3" />
    </svg>
  ),
  Briefcase: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <rect x="3" y="7" width="18" height="13" rx="2" /><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
    </svg>
  ),
  Activity: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M22 12h-4l-3 9L9 3l-3 9H2" />
    </svg>
  ),
  Grid: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <rect x="3" y="3" width="7" height="7" rx="1.5" />
      <rect x="14" y="3" width="7" height="7" rx="1.5" />
      <rect x="3" y="14" width="7" height="7" rx="1.5" />
      <rect x="14" y="14" width="7" height="7" rx="1.5" />
    </svg>
  ),
  Bolt: (p) => (
    <svg viewBox="0 0 24 24" fill="currentColor" {...p}>
      <path d="M13 2 3 14h7l-1 8 10-12h-7l1-8Z" />
    </svg>
  ),
  Moon: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z" />
    </svg>
  ),
  Plus: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" {...p}>
      <path d="M12 5v14M5 12h14" />
    </svg>
  ),
  ChevronR: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="m9 6 6 6-6 6" />
    </svg>
  ),
  ArrowUp: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M12 19V5M5 12l7-7 7 7" />
    </svg>
  ),
  ArrowDown: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M12 5v14M5 12l7 7 7-7" />
    </svg>
  ),
  Sparkles: (p) => (
    <svg viewBox="0 0 24 24" fill="currentColor" {...p}>
      <path d="M12 3l1.6 4.4L18 9l-4.4 1.6L12 15l-1.6-4.4L6 9l4.4-1.6Z" />
      <path d="M19 14l.8 2.2L22 17l-2.2.8L19 20l-.8-2.2L16 17l2.2-.8Z" />
    </svg>
  ),
  Filter: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M3 5h18l-7 9v6l-4-2v-4Z" />
    </svg>
  ),
  Clock: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" />
    </svg>
  ),
  Volume: (p) => (
    <svg viewBox="0 0 24 24" fill="currentColor" {...p}>
      <rect x="3" y="14" width="3" height="6" rx="1" />
      <rect x="8" y="9" width="3" height="11" rx="1" />
      <rect x="13" y="5" width="3" height="15" rx="1" />
      <rect x="18" y="11" width="3" height="9" rx="1" />
    </svg>
  ),
  Squeeze: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M4 6h16" /><path d="M6 12h12" /><path d="M4 18h16" />
    </svg>
  ),
  Help: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <circle cx="12" cy="12" r="9" /><path d="M9.5 9a2.5 2.5 0 1 1 4 2c-1.5.7-1.5 1.5-1.5 2" /><path d="M12 17h.01" />
    </svg>
  ),
  Share: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M12 4v12" /><path d="M7 9l5-5 5 5" /><path d="M5 16v3a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-3" />
    </svg>
  ),
  External: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M14 4h6v6" /><path d="M20 4 10 14" /><path d="M20 14v6H4V4h6" />
    </svg>
  ),
};

window.Icon = Icon;

// Sparkline bars
const SparkBars = ({ values, dir = 'bull' }) => {
  const max = Math.max(...values) || 1;
  return (
    <div className="micro-spark">
      {values.map((v, i) => (
        <div key={i} className="b" style={{ height: `${(v / max) * 100}%`, opacity: 0.4 + (v / max) * 0.6 }} />
      ))}
    </div>
  );
};
window.SparkBars = SparkBars;

// Header bar
const TopHeader = ({ tweaks }) => (
  <div className="header">
    <div className="header-logo">
      <Icon.Logo />
      <span className="badge">MA200</span>
    </div>
    <div className="header-meta">
      <div className="date">2026-05-06 · 07:55 PM</div>
      <div className="market"><span className="live-dot" /> Markets · Strong</div>
    </div>
    <button className="icon-btn" title="Refresh"><Icon.Refresh /></button>
    <button className="icon-btn" title="Alerts" style={{ position: 'relative' }}>
      <Icon.Bell />
      <span style={{ position: 'absolute', top: 6, right: 6, width: 8, height: 8, borderRadius: '50%', background: 'var(--bear)', border: '2px solid var(--bg-card)' }} />
    </button>
    <div className="avatar">Z</div>
  </div>
);
window.TopHeader = TopHeader;

// Timeframe selector
const TimeframeSel = ({ value, onChange }) => (
  <div className="tfs">
    {['4H', 'D', 'W', 'M'].map(tf => (
      <button key={tf} className={value === tf ? 'active' : ''} onClick={() => onChange(tf)}>{tf}</button>
    ))}
  </div>
);
window.TimeframeSel = TimeframeSel;

// Tab bar
const TabBar = ({ value, onChange }) => {
  const tabs = [
    { id: 'dashboard', label: 'Dashboard', icon: Icon.Grid },
    { id: 'signals',   label: 'Signals',   icon: Icon.Activity },
    { id: 'portfolio', label: 'Portfolio', icon: Icon.Briefcase },
    { id: 'watchlist', label: 'Watchlist', icon: Icon.Eye },
    { id: 'trends',    label: 'Trends',    icon: Icon.TrendUp },
  ];
  return (
    <nav className="tabbar">
      {tabs.map(t => {
        const I = t.icon;
        return (
          <button key={t.id} className={value === t.id ? 'active' : ''} onClick={() => onChange(t.id)}>
            <I /> <span>{t.label}</span>
          </button>
        );
      })}
    </nav>
  );
};
window.TabBar = TabBar;
