// SwingPulse v2 — Signals tab (scanner)
const SignalsIcon = window.Icon;
const Signals = ({ tweaks }) => {
  const Icon = SignalsIcon;
  const [filter, setFilter] = React.useState('All');
  const filters = [
    { id: 'All', label: 'All', num: 264 },
    { id: 'Buy', label: 'Buy', num: 18 },
    { id: 'Sell', label: 'Sell', num: 16 },
    { id: 'High', label: 'High Conf', num: 4 },
    { id: 'Squeeze', label: 'Squeeze', num: 48 },
    { id: 'Vol', label: 'Vol Spike', num: 107 },
    { id: 'Watch', label: 'Watch', num: 4 },
  ];

  return (
    <>
      <div className="scanner-search">
        <Icon.Search />
        <input placeholder="Search instruments, groups…" />
        <span className="kbd">⌘K</span>
      </div>

      <div className="filter-pills">
        {filters.map(f => (
          <button key={f.id} className={filter === f.id ? 'active' : ''} onClick={() => setFilter(f.id)}>
            {f.label} <span className="num">{f.num}</span>
          </button>
        ))}
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', margin: '4px 2px 10px' }}>
        <div style={{ fontSize: 11, color: 'var(--fg-3)', fontWeight: 600, letterSpacing: '0.04em' }}>
          18 RESULTS · sorted by confidence
        </div>
        <button className="icon-btn" style={{ width: 28, height: 28 }}><Icon.Filter /></button>
      </div>

      <div className="signal-list">
        <SignalRow tone="bull" ticker="EURUSD" group="Forex / Currency" price="1.1692" pctRow="+0.1% · -0.3%" pctTrend="bull"
                   chips={[{ label: 'NEUTRAL' }, { label: 'BP3', solid: 'bull' }, { label: 'STANDARD' }, { label: 'Quad Bull', tone: 'bull' }, { label: '4TF✓', tone: 'bull' }, { label: '1d ago' }, { label: 'SQUEEZE', tone: 'squeeze' }, { label: 'KEY LVL', tone: 'warn' }]}
                   maOrder={11} maTotal={18}
                   spark={[3,5,4,6,5,7,6,8]} />

        <SignalRow tone="bull" ticker="GBPSGD" group="Forex / Currency" price="1.7276" pctRow="+0.3% · +0.3%" pctTrend="bull"
                   chips={[{ label: 'UPTREND', tone: 'bull' }, { label: 'BP3', solid: 'bull' }, { label: 'STANDARD' }, { label: 'Counter-trend', tone: 'accent' }, { label: '1d ago' }, { label: '🌱 Young', tone: 'bull' }, { label: 'SQUEEZE', tone: 'squeeze' }, { label: 'KEY LVL', tone: 'warn' }, { label: '7d run', tone: 'accent' }]}
                   maOrder={6} maTotal={18}
                   spark={[2,3,2,4,3,5,4,6]} />

        <SignalRow tone="bull" ticker="GBPZAR" group="Forex / Currency" price="22.72" pctRow="+0.1% · +1.6%" pctTrend="bull"
                   chips={[{ label: 'UPTREND', tone: 'bull' }, { label: 'BP1', solid: 'bull' }, { label: 'STANDARD' }, { label: 'Counter-trend', tone: 'accent' }, { label: '1d ago' }, { label: '🌱 Young', tone: 'bull' }, { label: 'SQUEEZE', tone: 'squeeze' }, { label: 'KEY LVL', tone: 'warn' }, { label: '1d run', tone: 'accent' }]}
                   maOrder={5} maTotal={18}
                   spark={[1,3,2,4,3,5,6,7]} />

        <SignalRow tone="bull" ticker="GBPNZD" group="Forex / Currency" price="2.3042" pctRow="+0.3% · +0.6%" pctTrend="bull"
                   chips={[{ label: 'UPTREND', tone: 'bull' }, { label: 'BP3', solid: 'bull' }, { label: 'STANDARD' }, { label: 'Quad Bull', tone: 'bull' }, { label: '4TF✓', tone: 'bull' }, { label: '1d ago' }, { label: '🌱 Young', tone: 'bull' }, { label: 'SQUEEZE', tone: 'squeeze' }, { label: 'KEY LVL', tone: 'warn' }, { label: '1d run', tone: 'accent' }]}
                   maOrder={8} maTotal={18}
                   spark={[2,4,3,5,4,6,5,7]} />

        <SignalRow tone="bull" ticker="MFC" group="CAN60 / Financials" price="53.53" pctRow="+14.6% · +1.4%" pctTrend="bull"
                   chips={[{ label: 'UPTREND', tone: 'bull' }, { label: 'BP2', solid: 'warn' }, { label: 'STANDARD' }, { label: 'Quad Bull', tone: 'bull' }, { label: '4TF✓', tone: 'bull' }, { label: '1d ago' }, { label: 'Developing', tone: 'accent', icon: '📈' }]}
                   maOrder={14} maTotal={18}
                   spark={[1,2,3,4,5,6,7,8]} />

        <SignalRow tone="bear" ticker="NFLX" group="US100 / Comm. Services" price="612.40" pctRow="-2.8% · -1.1%" pctTrend="bear"
                   chips={[{ label: 'DOWNTREND', tone: 'bear' }, { label: 'SP1', solid: 'bear' }, { label: 'HIGH', tone: 'accent' }, { label: 'Triple Bear', tone: 'bear' }, { label: '4TF✓', tone: 'bear' }, { label: 'Today', tone: 'bear' }, { label: 'KEY LVL', tone: 'warn' }]}
                   maOrder={2} maTotal={18}
                   spark={[8,6,7,5,6,4,3,2]} />
      </div>
    </>
  );
};

const SignalRow = ({ tone, ticker, group, price, pctRow, chips, maOrder, maTotal, spark }) => {
  const fillPct = (maOrder / maTotal) * 100;
  return (
    <div className={`signal-row ${tone}`}>
      <div className="accent-bar" />
      <div className="signal-head">
        <div className="left">
          <div className="ticker-row">
            <span className="ticker">{ticker}</span>
            <span className="chip squeeze tiny">SQZ</span>
            <Icon.External style={{ width: 12, height: 12, color: 'var(--fg-3)' }} />
          </div>
          <div className="group">{group}</div>
        </div>
        <div className="right">
          <div className="price">{price}</div>
          <div className="pct">{pctRow}</div>
        </div>
      </div>

      <div className="signal-chips">
        {chips.map((c, i) => {
          let cls = 'chip';
          if (c.solid) cls += ` solid-${c.solid}`;
          else if (c.tone) cls += ` ${c.tone}`;
          return <span key={i} className={cls}>{c.icon ? `${c.icon} ${c.label}` : c.label}</span>;
        })}
      </div>

      <div className="signal-meta">
        <div className="ma-order">
          <span>MA Order</span>
          <div className="ma-bar"><div className="fill" style={{ width: `${fillPct}%` }} /></div>
          <span className="ma-num">{maOrder}/{maTotal}</span>
        </div>
      </div>
    </div>
  );
};

window.Signals = Signals;
