// SwingPulse v2 — App entry
const { useState, useEffect } = React;
const { IOSDevice, TweaksPanel, TweakSection, TweakColor, TweakRadio, TweakToggle, TweakSelect, useTweaks,
        TopHeader, TimeframeSel, TabBar, Dashboard, Signals, Watchlist, Trends, Portfolio } = window;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "indigo",
  "density": "default",
  "showAccentBars": true,
  "tab": "dashboard"
}/*EDITMODE-END*/;

const ACCENT_PALETTES = {
  indigo:  { '--accent': '#7c7cff', '--accent-2': '#9d8bff', '--accent-soft': 'rgba(124,124,255,0.14)', '--accent-glow': 'rgba(124,124,255,0.35)' },
  emerald: { '--accent': '#22d39a', '--accent-2': '#5fe2b4', '--accent-soft': 'rgba(34,211,154,0.14)',  '--accent-glow': 'rgba(34,211,154,0.35)' },
  amber:   { '--accent': '#f5a524', '--accent-2': '#ffc870', '--accent-soft': 'rgba(245,165,36,0.14)',  '--accent-glow': 'rgba(245,165,36,0.35)' },
  rose:    { '--accent': '#ff5d80', '--accent-2': '#ff90a8', '--accent-soft': 'rgba(255,93,128,0.14)',  '--accent-glow': 'rgba(255,93,128,0.35)' },
  cyan:    { '--accent': '#22b8d3', '--accent-2': '#5fd3e8', '--accent-soft': 'rgba(34,184,211,0.14)',  '--accent-glow': 'rgba(34,184,211,0.35)' },
};

function App() {
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [tab, setTab] = useState(tweaks.tab || 'dashboard');
  const [tf, setTf] = useState('D');

  useEffect(() => {
    const palette = ACCENT_PALETTES[tweaks.accent] || ACCENT_PALETTES.indigo;
    Object.entries(palette).forEach(([k, v]) => document.documentElement.style.setProperty(k, v));
  }, [tweaks.accent]);

  useEffect(() => {
    document.documentElement.dataset.density = tweaks.density;
  }, [tweaks.density]);

  return (
    <>
      <IOSDevice width={402} height={874} dark>
        <div className="app" data-screen-label={`0${['dashboard','signals','portfolio','watchlist','trends'].indexOf(tab)+1} ${tab}`}
             style={{ height: '100%', position: 'relative' }}>
          <div style={{ height: 50 }} /> {/* status bar room */}
          <TopHeader tweaks={tweaks} />
          <TimeframeSel value={tf} onChange={setTf} />
          <div className="scroll" key={tab}>
            {tab === 'dashboard' && <Dashboard tweaks={tweaks} timeframe={tf} />}
            {tab === 'signals' && <Signals tweaks={tweaks} />}
            {tab === 'watchlist' && <Watchlist tweaks={tweaks} />}
            {tab === 'trends' && <Trends tweaks={tweaks} />}
            {tab === 'portfolio' && <Portfolio tweaks={tweaks} />}
          </div>
          <TabBar value={tab} onChange={(t) => { setTab(t); setTweak('tab', t); }} />
        </div>
      </IOSDevice>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme">
          <TweakColor
            label="Accent"
            value={tweaks.accent}
            options={['indigo','emerald','amber','rose','cyan']}
            onChange={(v) => setTweak('accent', v)}
          />
        </TweakSection>

        <TweakSection label="Layout">
          <TweakRadio
            label="Density"
            value={tweaks.density}
            options={['compact','default','comfortable']}
            onChange={(v) => setTweak('density', v)}
          />
          <TweakToggle
            label="Signal accent bars"
            value={tweaks.showAccentBars}
            onChange={(v) => setTweak('showAccentBars', v)}
          />
        </TweakSection>

        <TweakSection label="Navigate">
          <TweakSelect
            label="Tab"
            value={tab}
            options={['dashboard','signals','portfolio','watchlist','trends']}
            onChange={(v) => { setTab(v); setTweak('tab', v); }}
          />
        </TweakSection>
      </TweaksPanel>
    </>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
