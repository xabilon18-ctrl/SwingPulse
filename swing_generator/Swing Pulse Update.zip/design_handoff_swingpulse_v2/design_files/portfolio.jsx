// SwingPulse v2 — Portfolio tab
const PfIcon = window.Icon;
const Portfolio = ({ tweaks }) => {
  const Icon = PfIcon;
  return (
    <>
      <div className="pf-hero">
        <div className="lbl">Equity · XM Live</div>
        <div className="balance mono">$24,816<span className="cents">.42</span></div>
        <div className="delta">
          <Icon.ArrowUp style={{ width: 12, height: 12 }} /> +$1,284.10 · +5.46% all-time
        </div>
        <div className="pf-bar">
          <div className="pf-seg" style={{ flex: 5, background: 'var(--bull)' }}>5 wins</div>
          <div className="pf-seg" style={{ flex: 2, background: 'var(--bear)' }}>2 loss</div>
          <div className="pf-seg" style={{ flex: 1, background: 'var(--bg-chip)', color: 'var(--fg-2)' }}>1 flat</div>
        </div>
        <div className="pf-legend">
          <div className="leg"><div className="sw" style={{ background: 'var(--bull)' }} /> 5 winners</div>
          <div className="leg"><div className="sw" style={{ background: 'var(--bear)' }} /> 2 losers</div>
          <div className="leg"><div className="sw" style={{ background: 'var(--bg-chip)' }} /> 1 flat</div>
        </div>
      </div>

      <div className="section-title"><div><h2>Open Positions</h2><div className="meta" style={{ marginTop: 2 }}>Auto-synced from XM</div></div><div className="link">Sync now <Icon.Refresh style={{ width: 11, height: 11 }} /></div></div>

      <PosRow side="buy" ticker="DAX" vol="2.5 lots" pnl="+$642.18" pnlPct="+3.2%" entry="24,200.50" current="24,401.70" sl="24,050.00" tp="24,700.00" trend="bull" />
      <PosRow side="buy" ticker="EURUSD" vol="1.0 lots" pnl="+$118.40" pnlPct="+1.0%" entry="1.1580" current="1.1692" sl="1.1500" tp="1.1800" trend="bull" />
      <PosRow side="sell" ticker="NFLX" vol="0.5 lots" pnl="+$284.20" pnlPct="+4.8%" entry="643.00" current="612.40" sl="660.00" tp="585.00" trend="bull" />
      <PosRow side="buy" ticker="GOLD" vol="0.3 lots" pnl="-$94.50" pnlPct="-0.8%" entry="4,592.20" current="4,555.80" sl="4,520.00" tp="4,700.00" trend="bear" />
      <PosRow side="buy" ticker="BTCUSD" vol="0.1 lots" pnl="+$326.80" pnlPct="+6.1%" entry="76,250.00" current="80,927.05" sl="74,000.00" tp="86,000.00" trend="bull" />

      <div className="section-title"><div><h2>Recent Activity</h2></div></div>
      <div className="card-quiet" style={{ padding: '4px 0' }}>
        <ActivityRow type="OPEN" ticker="MFC" desc="BUY 1.0 lots @ 53.53" time="14m ago" />
        <ActivityRow type="CLOSE" ticker="ASML" desc="SELL 0.5 · +$184.20" time="2h ago" tone="bull" />
        <ActivityRow type="ALERT" ticker="GBPNZD" desc="BP3 signal · 4TF aligned" time="3h ago" tone="accent" />
        <ActivityRow type="OPEN" ticker="DAX" desc="BUY 2.5 lots @ 24,200.50" time="1d ago" />
      </div>

      <div style={{ height: 30 }} />
    </>
  );
};

const PosRow = ({ side, ticker, vol, pnl, pnlPct, entry, current, sl, tp, trend }) => (
  <div className="pos-row">
    <div className="top">
      <div className="left">
        <span className={`side ${side}`}>{side.toUpperCase()}</span>
        <div>
          <div className="ticker">{ticker}</div>
          <div className="vol">{vol}</div>
        </div>
      </div>
      <div style={{ textAlign: 'right' }}>
        <div className={`pnl ${trend}`}>{pnl}</div>
        <div className={`pnl-pct ${trend}`}>{pnlPct}</div>
      </div>
    </div>
    <div className="meta">
      <div><div className="k">Entry</div><div className="v">{entry}</div></div>
      <div><div className="k">Now</div><div className="v">{current}</div></div>
      <div><div className="k">SL / TP</div><div className="v" style={{ fontSize: 11 }}>{sl} / {tp}</div></div>
    </div>
  </div>
);

const ActivityRow = ({ type, ticker, desc, time, tone }) => {
  const typeColor = type === 'CLOSE' ? 'var(--bull)' : type === 'ALERT' ? 'var(--accent-2)' : 'var(--fg-2)';
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '11px 14px', borderBottom: '1px solid var(--hairline)' }}>
      <div style={{ width: 6, height: 6, borderRadius: '50%', background: typeColor, flexShrink: 0 }} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 13, fontWeight: 600 }}>
          <span style={{ color: typeColor, fontSize: 10, fontWeight: 700, letterSpacing: '0.06em', marginRight: 6 }}>{type}</span>
          {ticker}
        </div>
        <div style={{ fontSize: 11, color: 'var(--fg-3)', marginTop: 1 }}>{desc}</div>
      </div>
      <div style={{ fontSize: 10, color: 'var(--fg-3)' }}>{time}</div>
    </div>
  );
};

window.Portfolio = Portfolio;
