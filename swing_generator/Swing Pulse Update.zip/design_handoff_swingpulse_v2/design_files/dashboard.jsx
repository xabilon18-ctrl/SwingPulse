// SwingPulse v2 — Dashboard tab
const { Icon } = window;
const Dashboard = ({ tweaks, timeframe }) => {
  const [heatFilter, setHeatFilter] = React.useState('All');

  return (
    <>
      {/* Market Pulse hero */}
      <div className="pulse-card">
        <div className="pulse-head">
          <div>
            <div className="label">Market Pulse</div>
            <h1>Strong conditions</h1>
          </div>
          <div className="pulse-tag">DAILY</div>
        </div>

        <div className="pulse-arc">
          <div className="gauge">
            <svg viewBox="0 0 130 90">
              <defs>
                <linearGradient id="gaugeStroke" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#ff5d6c" />
                  <stop offset="35%" stopColor="#f5a524" />
                  <stop offset="65%" stopColor="#7c7cff" />
                  <stop offset="100%" stopColor="#22d39a" />
                </linearGradient>
              </defs>
              {/* Track */}
              <path d="M 12 78 A 53 53 0 0 1 118 78" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="10" strokeLinecap="round" />
              {/* Score arc — 65/100 → 65% of half circle */}
              <path d="M 12 78 A 53 53 0 0 1 118 78" fill="none" stroke="url(#gaugeStroke)" strokeWidth="10" strokeLinecap="round" strokeDasharray="166" strokeDashoffset="58" />
              {/* Tick */}
              <g transform="translate(65 78) rotate(63)">
                <line x1="0" y1="0" x2="0" y2="-58" stroke="#fff" strokeWidth="2" strokeLinecap="round" />
                <circle cx="0" cy="-58" r="4" fill="#fff" />
              </g>
            </svg>
            <div className="score">
              <div className="score-num">65</div>
              <div className="score-label">/ 100</div>
            </div>
          </div>
          <div className="pulse-stats">
            <div className="pulse-stat">
              <div className="dot" style={{ background: 'var(--bull)' }} />
              <div className="name">Uptrend</div>
              <div className="val" style={{ color: 'var(--bull)' }}>102</div>
            </div>
            <div className="pulse-stat">
              <div className="dot" style={{ background: 'var(--bear)' }} />
              <div className="name">Downtrend</div>
              <div className="val" style={{ color: 'var(--bear)' }}>59</div>
            </div>
            <div className="pulse-stat">
              <div className="dot" style={{ background: 'var(--fg-3)' }} />
              <div className="name">Neutral</div>
              <div className="val" style={{ color: 'var(--fg-2)' }}>131</div>
            </div>
            <div className="pulse-stat">
              <div className="dot" style={{ background: 'var(--accent)' }} />
              <div className="name">Counter-trend</div>
              <div className="val" style={{ color: 'var(--accent-2)' }}>148</div>
            </div>
          </div>
        </div>
      </div>

      {/* Stat strip */}
      <div className="stat-strip">
        <StatMini tone="bull" label="Buy" value="18" icon={<Icon.TrendUp />} />
        <StatMini tone="bear" label="Sell" value="16" icon={<Icon.TrendDown />} />
        <StatMini tone="warn" label="Watch" value="4" icon={<Icon.Clock />} />
        <StatMini tone="accent" label="High Conf" value="22" icon={<Icon.Sparkles />} />
      </div>

      {/* Trend Change Alerts */}
      <div className="section-title">
        <div>
          <h2>Trend Change Alerts</h2>
          <div className="meta" style={{ marginTop: 2 }}>12 instruments flipped today</div>
        </div>
        <div className="link">See all <Icon.ChevronR /></div>
      </div>
      <div className="alert-row">
        <AlertCard tone="bull" code="BP1" ticker="GBPZAR" name="Trend Change" />
        <AlertCard tone="bear" code="SP1" ticker="NFLX" name="Netflix · Reversal" />
        <AlertCard tone="bull" code="BP3" ticker="DAX" name="Strong Signal" />
        <AlertCard tone="bull" code="BP3" ticker="APOLLO" name="Strong Signal" />
        <AlertCard tone="bear" code="SP3" ticker="HON" name="Honeywell" />
        <AlertCard tone="bull" code="BP1" ticker="EURJPY" name="Reversal" />
      </div>

      {/* Today's Opportunities */}
      <div className="section-title">
        <div>
          <h2>Today's Opportunities</h2>
          <div className="meta" style={{ marginTop: 2 }}>Filtered to 3TF aligned</div>
        </div>
        <div className="link">See all <Icon.ChevronR /></div>
      </div>
      <div className="opp-row">
        <OppCard tone="bear" ticker="ZAL" group="GER40" code="SP2" side="SELL" tf="3TF"
                 price="20.80" pct="-4.8%" sub="Triple Bear"
                 spark={[3,5,2,7,8,5,9,4]} />
        <OppCard tone="bull" ticker="DAX" group="EU Index" code="BP3" side="BUY" tf="3TF"
                 price="24,401.70" pct="+1.3%" sub="Quad Bull"
                 spark={[2,4,3,5,6,7,5,8]} />
        <OppCard tone="bull" ticker="XINHUA" group="Asia Index" code="BP2" side="BUY" tf="3TF"
                 price="4,112.16" pct="+0.5%" sub="Quad Bull"
                 spark={[3,4,2,5,6,5,7,8]} />
        <OppCard tone="bull" ticker="EURUSD" group="Forex" code="BP3" side="BUY" tf="3TF"
                 price="1.1692" pct="+0.1%" sub="Bullish lean"
                 spark={[2,3,4,3,5,6,7,7]} />
      </div>

      {/* Confidence */}
      <div className="section-title"><div><h2>Signal Confidence</h2></div></div>
      <div className="card conf-card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
          <div style={{ fontSize: 12, color: 'var(--fg-3)' }}>28 active signals</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 600 }}>264 instruments</div>
        </div>
        <div className="conf-bar">
          <div className="conf-seg high" style={{ flex: 4 }}>4</div>
          <div className="conf-seg std"  style={{ flex: 18 }}>18</div>
          <div className="conf-seg low"  style={{ flex: 6 }}>6</div>
          <div className="conf-seg none">236 idle</div>
        </div>
        <div className="conf-legend">
          <div className="key"><div className="sw" style={{ background: 'var(--accent)' }} /> High (4)</div>
          <div className="key"><div className="sw" style={{ background: 'var(--bull)' }} /> Standard (18)</div>
          <div className="key"><div className="sw" style={{ background: 'var(--warn)' }} /> Low (6)</div>
        </div>
        <div className="conf-list">
          <ConfRow ticker="DAX" group="EU Index" code="BP3" tone="bull" />
          <ConfRow ticker="AMBA" group="US100" code="BP3" tone="bull" />
          <ConfRow ticker="NFLX" group="US100" code="SP1" tone="bear" />
          <ConfRow ticker="SAB" group="SPAIN35" code="BP3" tone="bull" />
        </div>
      </div>

      {/* Timeframe Alignment */}
      <div className="section-title"><div><h2>Timeframe Alignment</h2></div></div>
      <div className="card" style={{ padding: 14 }}>
        <div className="align-grid">
          <AlignCell tone="bull-3" num="107" lbl="Quad Bull" />
          <AlignCell tone="bull-2" num="4" lbl="Triple Bull" />
          <AlignCell tone="warn" num="148" lbl="Counter-trend" />
          <AlignCell tone="bear-2" num="1" lbl="Double Bear" />
          <AlignCell tone="bear-2" num="11" lbl="Triple Bear" />
          <AlignCell tone="bear-3" num="21" lbl="Quad Bear" />
        </div>
      </div>

      {/* Heatmap */}
      <div className="section-title">
        <div><h2>Market Heatmap</h2><div className="meta" style={{ marginTop: 2 }}>Tap any tile to drill in</div></div>
      </div>
      <div className="card heat-card">
        <div className="heat-filters">
          {['All','Asia Index','CA Index','CAN60','Commodity','Crypto','EU Index','Forex','US100'].map(f => (
            <button key={f} className={heatFilter === f ? 'active' : ''} onClick={() => setHeatFilter(f)}>{f}</button>
          ))}
        </div>
        <div className="heat-grid">
          {HEATMAP_DATA.map((t, i) => (
            <div key={i} className={`heat-tile ${t.tone}`}>
              {t.signal && <span className="signal">{t.signal}</span>}
              <span className="tk">{t.tk}</span>
              <span className="underline" />
              {t.pulse && <span className="pulse-d" />}
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

const StatMini = ({ tone, label, value, icon }) => (
  <div className={`stat-mini ${tone}`}>
    <div className="ic-wrap">{React.cloneElement(icon, { className: 'ic' })}</div>
    <div className="label">{label}</div>
    <div className="val">{value}</div>
  </div>
);

const AlertCard = ({ tone, code, ticker, name }) => (
  <div className={`alert-card ${tone}`}>
    <span className="code">{code}</span>
    <div className="ticker">{ticker}</div>
    <div className="name">{name}</div>
    <div className="foot">
      <span className="arrow">{tone === 'bull' ? '▲' : '▼'}</span> Trend change
    </div>
  </div>
);

const OppCard = ({ tone, ticker, group, code, side, tf, price, pct, sub, spark }) => {
  const max = Math.max(...spark);
  return (
    <div className={`opp-card ${tone}`}>
      <div className="top-bar" />
      <div className="head">
        <div>
          <div className="ticker">{ticker}</div>
          <div className="group">{group}</div>
        </div>
      </div>
      <div className="chips">
        <span className={`chip ${tone === 'bull' ? 'solid-bull' : 'solid-bear'}`}>{code}</span>
        <span className="chip">{side}</span>
        <span className="chip accent">{tf}</span>
      </div>
      <div className="price mono">{price}</div>
      <div className="pct"><span className="arr">{tone === 'bull' ? '▲' : '▼'}</span> {pct} · <span style={{ color: 'var(--fg-3)' }}>{sub}</span></div>
      <div className="spark">
        {spark.map((v, i) => (
          <div key={i} className="b" style={{ height: `${(v / max) * 100}%` }} />
        ))}
      </div>
    </div>
  );
};

const ConfRow = ({ ticker, group, code, tone }) => (
  <div className="conf-row">
    <div className="left">
      <div className="ticker">{ticker}</div>
      <span className={`chip ${tone === 'bull' ? 'solid-bull' : 'solid-bear'} tiny`}>{code}</span>
    </div>
    <div className="group">{group}</div>
  </div>
);

const AlignCell = ({ tone, num, lbl }) => (
  <div className={`align-cell ${tone}`}>
    <div className="num mono">{num}</div>
    <div className="lbl">{lbl}</div>
  </div>
);

// Heatmap data (matches v1 screenshot vibe)
const HEATMAP_DATA = [
  { tk: 'GOLD', tone: 'warn' }, { tk: 'SILVER', tone: 'warn' }, { tk: 'WTI', tone: 'bull', pulse: true },
  { tk: 'BTCUSD', tone: 'warn' }, { tk: 'ETHUSD', tone: 'warn' },
  { tk: 'XRPUSDT', tone: 'warn' }, { tk: 'ALGO', tone: 'warn' }, { tk: 'LINK', tone: 'warn' },
  { tk: 'APTUSDT', tone: 'bear', pulse: true }, { tk: 'APEUSDT', tone: 'warn' },
  { tk: 'ATOMUSDT', tone: 'warn' }, { tk: 'AVAX', tone: 'warn' }, { tk: 'BNBUSDT', tone: 'warn' },
  { tk: 'DOGE', tone: 'warn' }, { tk: 'DOTUSDT', tone: 'warn' },
  { tk: 'DYDX', tone: 'warn' }, { tk: 'SHIB', tone: 'warn' }, { tk: 'SOLUSDT', tone: 'warn' },
  { tk: 'UNI', tone: 'bear', pulse: true }, { tk: 'MASK', tone: 'bear' },
  { tk: 'OP', tone: 'warn' }, { tk: 'CHZ', tone: 'warn' }, { tk: 'TWT', tone: 'warn' },
  { tk: 'US500', tone: 'bull', pulse: true }, { tk: 'US100', tone: 'bull', pulse: true },
  { tk: 'US30', tone: 'bull', pulse: true }, { tk: 'RUSSEL', tone: 'bull', pulse: true }, { tk: 'SPAIN', tone: 'warn' },
  { tk: 'UK100', tone: 'bull' }, { tk: 'NETH25', tone: 'bull', pulse: true },
  { tk: 'IT40', tone: 'bull' }, { tk: 'EU50', tone: 'warn' }, { tk: 'DAX', tone: 'bull', pulse: true, signal: 'BP3' },
  { tk: 'FRA40', tone: 'warn' }, { tk: 'SW20', tone: 'bull', pulse: true },
  { tk: 'CAN60', tone: 'bull', pulse: true }, { tk: 'NQTW', tone: 'bull', pulse: true }, { tk: 'NI225', tone: 'bull', pulse: true },
  { tk: 'XINHUA', tone: 'bull', pulse: true, signal: 'BP2' }, { tk: 'HSI', tone: 'bull', pulse: true },
];

window.Dashboard = Dashboard;
