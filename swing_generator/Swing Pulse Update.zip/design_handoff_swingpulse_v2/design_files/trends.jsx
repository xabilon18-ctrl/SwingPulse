// SwingPulse v2 — Trends tab
const TrendsIcon = window.Icon;
const Trends = ({ tweaks }) => {
  const Icon = TrendsIcon;
  return (
    <>
      {/* Hero stats — 6 numbers from screenshot */}
      <div className="trend-hero">
        <div className="head">
          <div>
            <div style={{ fontSize: 11, color: 'var(--fg-3)', fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase' }}>
              All Trends · Lifetime
            </div>
            <h3>Universe trend stats</h3>
            <div className="sub">Across 264 instruments tracked</div>
          </div>
          <span className="chip accent">DAILY</span>
        </div>
        <div className="stats" style={{ gridTemplateColumns: 'repeat(2, 1fr)' }}>
          <div className="stat"><div className="v bull">3,707</div><div className="l">Uptrends</div></div>
          <div className="stat"><div className="v" style={{ color: 'var(--bear)' }}>3,772</div><div className="l">Downtrends</div></div>
          <div className="stat"><div className="v bull">283d</div><div className="l">Avg up</div></div>
          <div className="stat"><div className="v" style={{ color: 'var(--bear)' }}>151d</div><div className="l">Avg down</div></div>
          <div className="stat"><div className="v bull">+39.9%</div><div className="l">Avg up move</div></div>
          <div className="stat"><div className="v" style={{ color: 'var(--bear)' }}>-9.2%</div><div className="l">Avg down move</div></div>
        </div>
      </div>

      {/* Mini chart */}
      <div className="trend-chart-wrap">
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
          <div>
            <div style={{ fontSize: 11, color: 'var(--fg-3)', fontWeight: 600, letterSpacing: '0.04em', textTransform: 'uppercase' }}>Up vs Down (60d)</div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 16, fontWeight: 700, marginTop: 2 }}>Uptrend dominance <span style={{ color: 'var(--bull)' }}>+18%</span></div>
          </div>
        </div>
        <div className="trend-chart">
          <svg viewBox="0 0 300 130" preserveAspectRatio="none" style={{ width: '100%', height: '100%' }}>
            <defs>
              <linearGradient id="bullArea" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="var(--bull)" stopOpacity="0.4" />
                <stop offset="100%" stopColor="var(--bull)" stopOpacity="0" />
              </linearGradient>
            </defs>
            {/* Up area */}
            <path d="M 0 80 L 20 70 L 40 75 L 60 60 L 80 65 L 100 50 L 120 55 L 140 45 L 160 40 L 180 35 L 200 38 L 220 30 L 240 28 L 260 25 L 280 22 L 300 18 L 300 130 L 0 130 Z" fill="url(#bullArea)" />
            <path d="M 0 80 L 20 70 L 40 75 L 60 60 L 80 65 L 100 50 L 120 55 L 140 45 L 160 40 L 180 35 L 200 38 L 220 30 L 240 28 L 260 25 L 280 22 L 300 18" fill="none" stroke="var(--bull)" strokeWidth="2" />
            {/* Down line */}
            <path d="M 0 50 L 20 60 L 40 55 L 60 70 L 80 65 L 100 80 L 120 75 L 140 85 L 160 90 L 180 95 L 200 92 L 220 100 L 240 102 L 260 105 L 280 108 L 300 112" fill="none" stroke="var(--bear)" strokeWidth="2" strokeDasharray="3 3" opacity="0.7" />
          </svg>
        </div>
      </div>

      {/* Search + sort */}
      <div className="section-title"><div><h2>Active Runs</h2><div className="meta" style={{ marginTop: 2 }}>Longest first</div></div></div>
      <div className="scanner-search" style={{ marginBottom: 8 }}>
        <Icon.Search />
        <input placeholder="Search instrument…" />
      </div>
      <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
        <button className="chip" style={{ flex: 1, justifyContent: 'space-between', padding: '8px 12px' }}>All Groups ▼</button>
        <button className="chip" style={{ flex: 1, justifyContent: 'space-between', padding: '8px 12px' }}>Run ↓</button>
      </div>

      <div className="trend-list">
        <TrendItem dir="up" name="DELL" group="NYSE" days="47d" pct="+62.4%" />
        <TrendItem dir="dn" name="APTUSDT" group="Crypto" days="39d" pct="-21.3%" />
        <TrendItem dir="up" name="SIRI" group="US100" days="31d" pct="+18.9%" />
        <TrendItem dir="up" name="BAS" group="GER40" days="28d" pct="+11.4%" />
        <TrendItem dir="up" name="BNR" group="GER40" days="28d" pct="+9.2%" />
        <TrendItem dir="up" name="MRVL" group="US100" days="25d" pct="+33.7%" />
        <TrendItem dir="up" name="ARM" group="US100" days="25d" pct="+44.1%" />
        <TrendItem dir="up" name="DAX" group="EU Index" days="22d" pct="+8.6%" />
        <TrendItem dir="dn" name="NFLX" group="US100" days="14d" pct="-12.8%" />
      </div>
    </>
  );
};

const TrendItem = ({ dir, name, group, days, pct }) => (
  <div className="trend-item">
    <div className={`dir ${dir}`}>{dir === 'up' ? 'UP' : 'DOWN'}</div>
    <div className="info">
      <div className="top">{name} <span style={{ color: 'var(--fg-3)', fontSize: 11, fontWeight: 500 }}>· {group}</span></div>
      <div className="dates">Started 47d ago · still running</div>
    </div>
    <div>
      <div className={`move ${dir === 'up' ? 'bull' : 'bear'} mono`}>{pct}</div>
      <div className="days">{days} run</div>
    </div>
  </div>
);

window.Trends = Trends;
