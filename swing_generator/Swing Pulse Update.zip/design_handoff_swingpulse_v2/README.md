# Handoff: SwingPulse v2

## Overview

SwingPulse v2 is a mobile-first visual + interaction redesign of the existing SwingPulse signals dashboard (currently live at https://swingpulse200.pages.dev/). It keeps every existing tab, signal type, and data shape from v1 — but reorganizes layout, adds a refined design token system, and pushes the dark "Bloomberg-meets-modern-fintech" aesthetic significantly further.

The redesign covers all 5 tabs: **Dashboard, Signals (formerly Scanner), Watchlist, Trends, Portfolio**.

## About the Design Files

The files in `design_files/` are **design references created in HTML/JSX** — high-fidelity prototypes showing the intended look, layout, and interactions. They are **not production code to copy directly**.

The current SwingPulse codebase (`xabilon18/SwingPulse`) is a **vanilla JS + Chart.js single-page app** served from `swing_generator/webapp/` with `index.html`, `style.css`, `app.js`, and a Python publisher (`publish.py`). The prototype here was built in React/JSX for fast iteration — when implementing, **port the visual design into the existing vanilla-JS architecture**, not the other way around. Do not introduce React, a build step, or a framework migration as part of this work.

The CSS in `design_files/` (especially `tokens.css`, `app.css`, `dashboard.css`, `tabs.css`) is **directly copy-pasteable** into `style.css` with minor scoping tweaks — that's the fastest path to pixel parity.

## Fidelity

**High-fidelity.** Final colors, typography, spacing, radii, shadows, and motion are all production-ready values. The developer should recreate the UI pixel-perfectly using the existing vanilla JS + Chart.js stack.

## Migration Strategy (recommended)

1. **Land design tokens first** — copy `tokens.css` into the top of `style.css`. This gives you all CSS variables (`--bg`, `--fg`, `--accent`, `--bull`, `--bear`, etc.) used everywhere else.
2. **Replace global shell + tab bar** (`app.css` rules under `.app`, `.header`, `.tabbar`, `.scroll`, `.tfs`, `.section-title`, `.card`, `.chip`).
3. **Migrate one tab at a time, in this order** (highest visual ROI first):
   1. Dashboard — biggest impact, see `dashboard.jsx` + `dashboard.css`
   2. Signals — see `signals.jsx`
   3. Watchlist — see `watchlist.jsx`
   4. Portfolio — see `portfolio.jsx`
   5. Trends — see `trends.jsx`
4. **Bump `app.js` and `style.css` cache-busting versions** (the repo uses `?v=NN` query strings) and deploy via `python3 webapp/publish.py --profile ma200 --ui-only`.
5. **Tweaks panel is optional** — `tweaks-panel.jsx` is a dev/design control surface for swapping accent palettes and density. You don't need to ship it; pick one accent + density and bake it in. (Indigo + comfortable is the recommended default.)

## Screens / Views

The app is a 5-tab mobile shell. All tabs live inside the same shell (`.app`) with a shared sticky header and bottom tab bar.

### Shell (always present)

- **Header** (`.header`, 14px top / 8px bottom padding, var(--pad) horizontal):
  - Logo: 36×36 rounded-10 gradient square (`linear-gradient(135deg, var(--accent), var(--accent-2))`) with white SVG bolt icon and tiny "v2" badge bottom-right.
  - Meta block: tiny uppercase date (11px, --fg-3) + market state line ("Markets Open · 2:14 PM ET", 14px, 600 weight) with a pulsing green `--bull` dot.
  - Two icon buttons (search, bell) — 36×36, rounded-10, `--bg-card` with hairline border.
  - Avatar: 36×36 round gradient with user initial.
- **Timeframe selector** (`.tfs`, only on Dashboard): 4-button segmented control — 1D / 1W / 1M / 3M. Active state: indigo gradient pill with `--accent-glow` shadow.
- **Bottom tab bar** (`.tabbar`): 5 equal columns — Dashboard, Signals, Watchlist, Trends, Portfolio. Active state: `--accent-2` text color + 28×2px indigo bar above the icon with a soft glow. Background fades from transparent to `--bg` so content scrolls under it cleanly.
- **Scroll region** (`.scroll`): single vertical scroll area, `100px` bottom padding to clear the tab bar; scrollbar hidden.

### Dashboard

The new Dashboard is composed of these sections in order. See `dashboard.jsx` for exact JSX, `dashboard.css` for layout rules.

1. **Market Pulse hero card** — full-width card with a circular arc gauge on the left (SVG, 0–100 score, accent-color stroke with glow) and a 3-row stat stack on the right (Bull Signals / Bear Signals / Net Flow). Subtle radial glow behind the gauge.
2. **Alerts strip** — horizontal-scrolling row of alert cards (each ~220px wide). Each card has: ticker, alert type chip (BP1, SP2, etc.), price, % change, micro-sparkline.
3. **Top Opportunities** — horizontal-scroll cards, 240px wide, with: ticker + name, signal pill, confidence bar, larger sparkline, entry/SL/TP mini-table.
4. **Confidence Stack** — vertical stack of 4 horizontal bars (High / Medium / Low / Speculative) with count + colored fill that animates on tab enter.
5. **Trend Alignment Grid** — 2×2 grid showing alignment across timeframes (1D/1W/1M/3M). Each cell is a card with a directional arrow, % aligned, and a colored hairline.
6. **Signal Heatmap** — denser version of v1's heatmap. Grid of small ticker tiles colored by signal strength (bull green → bear red), with the signal label (BP1/SP3/etc.) overlaid.

### Signals (formerly Scanner)

See `signals.jsx`. Vertical list of signal rows. Each row has a left **accent bar** colored by signal direction (green for BP, red for SP, indigo for squeeze). Inside each row:

- Ticker + company name (left).
- Signal pill (BP1–BP4 / SP1–SP4 / SQUEEZE).
- Price + % change (mono, tabular-nums).
- **MA Order progress bar** — horizontal bar showing how many of the MAs are stacked correctly (e.g. 4/5).
- Micro sparkline (right).

Above the list:
- Search field (rounded-md, --bg-card).
- Filter pills row: All / BP / SP / Squeeze / High Confidence — each shows a count.

### Watchlist

See `watchlist.jsx`.

- **Summary row at top**: 3 stat cards (Total / Bullish / Bearish) with counts.
- **Asset chips list**: rounded cards with ticker, current price, % change, and an alert badge if a signal is firing. Tappable to open detail.

### Trends

See `trends.jsx`.

- **6 stat hero**: 2×3 grid of stat tiles (Avg Win, Avg Loss, Win Rate, Total Signals, Best Sector, Worst Sector).
- **Up vs Down 60-day chart**: stacked area / bar chart (use Chart.js — pass `--bull` and `--bear` as CSS variables resolved via `getComputedStyle`).
- **Run list**: vertical list of recent signal runs with timestamp, ticker, P/L.

### Portfolio

See `portfolio.jsx`.

- **Balance hero card**: large balance number (mono, 32px), today's P/L delta with green/red color, sparkline.
- **Win/Loss ratio bar**: horizontal split bar (green wins / red losses) with percentages.
- **Position cards**: each card has ticker, qty, entry price, current price, SL/TP mini-readouts, P/L delta.
- **Activity feed**: chronological list of fills, signal triggers, and alerts.

## Interactions & Behavior

- **Tab switching**: instant, no transition. Bottom-bar active indicator slides on hover or selection (CSS `.active` class).
- **Timeframe selector** (Dashboard): swaps the dataset feeding all dashboard sections. Active button gets the indigo gradient.
- **Horizontal scroll cards** (Alerts, Opportunities): native momentum scroll, scrollbar hidden, 12px gap, edge fade is optional.
- **Pulse animation** on live-market dot: 2s infinite, see `@keyframes pulse` in `app.css`.
- **Shimmer loading state**: `.shimmer` class — useful for skeletons while signals stream in. See `@keyframes shimmer` in `app.css`.
- **Tweaks panel** (dev only): `tweaks-panel.jsx` exposes accent color, density, and tab navigation. Skip when shipping; keep one accent and one density baked in.
- No page transitions, no modal animations specified beyond what's in the CSS — keep it snappy.

## State Management

The existing v1 app already manages all state needed (signal list, watchlist, portfolio positions, current tab). v2 does not introduce new state shapes. New visual elements (arc gauge, progress bars, sparklines) read from the existing data:

- Arc gauge value: derived from existing bull/bear count (e.g. `bullCount / (bullCount + bearCount) * 100`).
- Confidence stack: existing confidence levels.
- MA Order progress: derived from existing MA-alignment fields.
- Sparklines: existing price history arrays — render via Chart.js with axes/grid hidden, 1.5px line, color = `--bull` or `--bear` based on first-vs-last delta.

## Design Tokens

All values from `tokens.css`. Copy that file's `:root` block into the top of `style.css`.

### Surfaces (dark navy)
- `--bg: #07090f` — app background
- `--bg-elev: #0d1018`
- `--bg-card: #11141d` — primary card surface
- `--bg-card-2: #161a25` — nested / secondary surface
- `--bg-chip: #1a1f2c`
- `--hairline: rgba(255,255,255,0.06)` — primary border
- `--hairline-2: rgba(255,255,255,0.10)` — emphasized border

### Text
- `--fg: #e9ecf3` — primary text
- `--fg-2: #a4abbd` — secondary
- `--fg-3: #6b7184` — tertiary / labels
- `--fg-4: #444a5c` — disabled / divider-on-card

### Accent (indigo-violet, recommended default)
- `--accent: #7c7cff`
- `--accent-2: #9d8bff`
- `--accent-soft: rgba(124,124,255,0.14)` — chip / soft fill
- `--accent-glow: rgba(124,124,255,0.35)` — for shadow glows

### Signals
- `--bull: #22d39a` (with `--bull-soft` and `--bull-glow`)
- `--bear: #ff5d6c` (with `--bear-soft` and `--bear-glow`)
- `--warn: #f5a524` (with `--warn-soft`)
- `--squeeze: #b08bff` (with `--squeeze-soft`) — for SQUEEZE signal

### Radii
- `--r-sm: 10px`
- `--r-md: 14px`
- `--r-lg: 20px` — primary card radius
- `--r-xl: 26px`

### Spacing (tweakable via `[data-density]`)
- `--pad: 16px` (default) / 12px compact / 18px comfortable
- `--gap: 12px` (default) / 8px compact / 14px comfortable

### Typography
- `--font-display: 'Inter Tight', 'Inter', system-ui, sans-serif` — section titles, hero numbers
- `--font-body: 'Inter', system-ui, sans-serif` — default UI text
- `--font-mono: 'JetBrains Mono', 'SF Mono', ui-monospace, monospace` — all numbers, tickers, prices
- Body smoothing: `-webkit-font-smoothing: antialiased`
- Tabular figures + ss01: `font-feature-settings: 'cv11','ss01','tnum'`
- Mono numbers must use `font-variant-numeric: tabular-nums` (utility: `.mono`)

Add to `<head>`:
```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Inter+Tight:wght@600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
```

### Shadows / Glows
No flat box-shadows — use colored glow halos:
- Primary CTA glow: `0 4px 10px -4px var(--accent-glow)`
- Logo halo: `0 8px 22px -10px var(--accent-glow)`

## Assets

- **Icons**: Lucide-style stroke icons inline as SVG (16–22px, `stroke-width: 1.75`). The prototype uses inline SVG paths in `shared.jsx` — feel free to swap for the existing icon set in v1, sizes/strokes match.
- **Logo glyph**: simple bolt/lightning shape inside the gradient square. The current v1 logo can be reused — just set the gradient background per the spec.
- **No external images** are needed for the core experience.

## Files

In `design_files/`:

- `SwingPulse v2.html` — the live prototype. Open this directly to see the full v2 in an iOS frame.
- `tokens.css` — **copy first**. Design system variables.
- `app.css` — global shell, header, tab bar, timeframe selector, cards, chips, animations.
- `dashboard.css` — Dashboard-specific layout (gauge, alert strip, opportunity cards, confidence stack, alignment grid, heatmap).
- `tabs.css` — shared tab content rules.
- `app.jsx` — top-level shell + tab routing (reference for component composition only — do **not** port React).
- `dashboard.jsx`, `signals.jsx`, `watchlist.jsx`, `trends.jsx`, `portfolio.jsx` — per-tab markup. Use these as visual references; translate the JSX into the equivalent vanilla-JS DOM construction in `app.js`.
- `ios-frame.jsx` — preview-only iPhone bezel. Discard when shipping.
- `tweaks-panel.jsx` — dev-only design tweak surface. Discard when shipping (or keep behind a query-string flag for design QA).
- `shared.jsx` — shared inline SVG icons. Cross-reference with the existing icon set in v1.

## Open questions for the implementer

- Confirm Chart.js is still the chosen library for sparklines + the Trends 60-day chart (the prototype mocks them with SVG; production should use Chart.js with `getComputedStyle` to resolve token colors).
- Decide whether to keep the Tweaks panel behind `?tweaks=1` for design QA, or strip entirely.
- The "Squeeze" signal style (`--squeeze`) is new in v2 — confirm v1 actually has a squeeze signal type, or remove if unused.
